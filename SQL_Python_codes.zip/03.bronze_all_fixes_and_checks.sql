/* ==========================================================
   FRAUD ANALYTICS – BRONZE LAYER FIXES & CHECKS (MASTER)
   ----------------------------------------------------------
   This script:
   1) Drops all SILVER & GOLD tables and schemas
   2) Recreates stg.transactions with correct columns
   3) Applies schema fixes to:
        - stg.login_events
        - stg.chargebacks
        - stg.merchants
   4) Provides verification queries for all stg tables
   ========================================================== */


--------------------------------------------------------------
-- 1. DROP ALL TABLES IN SILVER & GOLD
--    (We are rebuilding Silver & Gold cleanly later.)
--------------------------------------------------------------
DECLARE @sql NVARCHAR(MAX) = N'';

SELECT @sql = @sql + 'DROP TABLE [' + s.name + '].[' + t.name + '];' + CHAR(10)
FROM sys.tables t
JOIN sys.schemas s ON t.schema_id = s.schema_id
WHERE s.name IN ('silver', 'gold');

PRINT @sql;  -- optional: see what will be dropped
EXEC sp_executesql @sql;


--------------------------------------------------------------
-- 2. DROP SILVER & GOLD SCHEMAS (IF NOW EMPTY)
--------------------------------------------------------------
IF EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'silver')
BEGIN
    DROP SCHEMA silver;
END;

IF EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'gold')
BEGIN
    DROP SCHEMA gold;
END;


--------------------------------------------------------------
-- 3. RECREATE STG.TRANSACTIONS WITH CORRECT COLUMNS
--    (Bronze/raw table – all text-like, no strong typing.)
--    This fixes ADF errors:
--       - Column 'txn_id' does not exist
--       - Column 'card_id' does not exist
--------------------------------------------------------------
DROP TABLE IF EXISTS stg.transactions;

CREATE TABLE stg.transactions (
    txn_id            nvarchar(64)   NULL,  -- transaction ID
    account_id        nvarchar(64)   NULL,  -- account identifier
    card_id           nvarchar(64)   NULL,  -- card identifier
    merchant_id       nvarchar(64)   NULL,
    device_id         nvarchar(64)   NULL,
    txn_dt            nvarchar(50)   NULL,  -- raw timestamp text
    amount            nvarchar(50)   NULL,  -- raw amount text
    currency          nvarchar(10)   NULL,
    country_iso       nvarchar(3)    NULL,
    city              nvarchar(128)  NULL,
    channel           nvarchar(32)   NULL,
    entry_mode        nvarchar(32)   NULL,
    ip                nvarchar(64)   NULL,
    distance_km_prev  nvarchar(50)   NULL,
    txn_in_last_min5  nvarchar(50)   NULL,
    is_international  nvarchar(10)   NULL,
    is_new_device     nvarchar(10)   NULL,
    is_night          nvarchar(10)   NULL,
    is_high_amount    nvarchar(10)   NULL,
    is_fraud          nvarchar(10)   NULL
);


--------------------------------------------------------------
-- 4. STG.LOGIN_EVENTS – RELAX NULLS + WIDEN TEXT COLUMNS
--    (We had to adjust these to avoid bulk copy issues and
--     allow blanks/nulls coming from Bronze.)
--------------------------------------------------------------

-- Drop index that depends on event_dt so we can alter the column
IF EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_stg_login_events_cust_dt'
      AND object_id = OBJECT_ID('stg.login_events')
)
BEGIN
    DROP INDEX IX_stg_login_events_cust_dt ON stg.login_events;
END;
GO

-- Allow NULLs and use suitable types/lengths
ALTER TABLE stg.login_events
    ALTER COLUMN event_dt    datetime2     NULL;     -- was NOT NULL

ALTER TABLE stg.login_events
    ALTER COLUMN ip          varchar(64)   NULL;
ALTER TABLE stg.login_events
    ALTER COLUMN mfa_used    varchar(10)   NULL;     -- true/false / yes/no
ALTER TABLE stg.login_events
    ALTER COLUMN device_type varchar(64)   NULL;
ALTER TABLE stg.login_events
    ALTER COLUMN success     varchar(10)   NULL;     -- 0/1 / true/false
ALTER TABLE stg.login_events
    ALTER COLUMN reason_code varchar(100)  NULL;
ALTER TABLE stg.login_events
    ALTER COLUMN country_iso varchar(10)   NULL;     -- e.g. "US", "GB"
GO

-- Re-create the index after altering event_dt
CREATE NONCLUSTERED INDEX IX_stg_login_events_cust_dt
ON stg.login_events (cust_id, event_dt);
GO


--------------------------------------------------------------
-- 5. STG.CHARGEBACKS – ALLOW NULLS WHERE BRONZE HAS BLANKS
--------------------------------------------------------------
ALTER TABLE stg.chargebacks
    ALTER COLUMN filed_dt    datetime2    NULL;      -- was NOT NULL

ALTER TABLE stg.chargebacks
    ALTER COLUMN won_dispute varchar(10)  NULL;      -- 'Y'/'N' or similar
GO


--------------------------------------------------------------
-- 6. STG.MERCHANTS – FIX NULLABILITY + LENGTH ISSUES
--------------------------------------------------------------

-- Widen merchant_id so bulk copy never breaks on length
ALTER TABLE stg.merchants
    ALTER COLUMN merchant_id varchar(128) NOT NULL;  -- was varchar(64)

-- Columns that caused DBNull / constraint errors
ALTER TABLE stg.merchants
    ALTER COLUMN category_mcc varchar(10)  NULL;     -- was NOT NULL
ALTER TABLE stg.merchants
    ALTER COLUMN risk_bucket  varchar(16)  NULL;     -- allow NULLs
ALTER TABLE stg.merchants
    ALTER COLUMN country_iso  varchar(10)  NULL;     -- was char(2) NOT NULL
GO


--------------------------------------------------------------
-- 7. ROW COUNTS FOR ALL STG TABLES
--    (Quick overview after pipeline run)
--------------------------------------------------------------
SELECT 
    s.name AS schema_name,
    t.name AS table_name,
    SUM(p.rows) AS row_count
FROM sys.tables t
JOIN sys.schemas s ON t.schema_id = s.schema_id
JOIN sys.partitions p 
    ON t.object_id = p.object_id 
    AND p.index_id IN (0,1)
WHERE s.name = 'stg'
GROUP BY s.name, t.name
ORDER BY t.name;


--------------------------------------------------------------
-- 8. SIMPLE ROW COUNT CHECKS PER TABLE
--------------------------------------------------------------
SELECT COUNT(*) AS row_count_accounts      FROM stg.accounts;
SELECT COUNT(*) AS row_count_chargebacks   FROM stg.chargebacks;
SELECT COUNT(*) AS row_count_devices       FROM stg.devices;
SELECT COUNT(*) AS row_count_ip_reputation FROM stg.ip_reputation;
SELECT COUNT(*) AS row_count_login_events  FROM stg.login_events;
SELECT COUNT(*) AS row_count_merchants     FROM stg.merchants;
SELECT COUNT(*) AS row_count_transactions  FROM stg.transactions;


--------------------------------------------------------------
-- 9. SAMPLE DATA FROM EACH STG TABLE (TOP 10)
--------------------------------------------------------------
SELECT TOP 10 * FROM stg.accounts;
SELECT TOP 10 * FROM stg.chargebacks;
SELECT TOP 10 * FROM stg.devices;
SELECT TOP 10 * FROM stg.ip_reputation;
SELECT TOP 10 * FROM stg.login_events;
SELECT TOP 10 * FROM stg.merchants;
SELECT TOP 10 * FROM stg.transactions;


--------------------------------------------------------------
-- 10. COLUMN METADATA FOR A GIVEN STG TABLE
--     (Change 'transactions' to inspect another table.)
--------------------------------------------------------------
SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'stg'
  AND TABLE_NAME   = 'transactions';   -- change table name as needed
