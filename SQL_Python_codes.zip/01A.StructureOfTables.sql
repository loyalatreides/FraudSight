
SELECT DB_NAME() AS current_db, ORIGINAL_LOGIN() AS original_login, SUSER_SNAME() AS suser;

-- Use the exact string from your server's "Microsoft Entra admin" line:
-- kamranhabib1212_gmail.com#EXT#@kamranhabib1212gmail.onmicrosoft.com
CREATE USER [kamranhabib1212_gmail.com#EXT#@kamranhabib1212gmail.onmicrosoft.com] FROM EXTERNAL PROVIDER;

ALTER ROLE db_datareader ADD MEMBER [kamranhabib1212_gmail.com#EXT#@kamranhabib1212gmail.onmicrosoft.com];
ALTER ROLE db_datawriter ADD MEMBER [kamranhabib1212_gmail.com#EXT#@kamranhabib1212gmail.onmicrosoft.com];
ALTER ROLE db_ddladmin  ADD MEMBER [kamranhabib1212_gmail.com#EXT#@kamranhabib1212gmail.onmicrosoft.com];

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'stg')
    EXEC('CREATE SCHEMA stg AUTHORIZATION dbo');
GO


-- Main Fact Table(Transactions)
IF OBJECT_ID('stg.transactions','U') IS NOT NULL DROP TABLE stg.transactions;
GO
CREATE TABLE stg.transactions (
    txn_id              VARCHAR(64)   NOT NULL PRIMARY KEY,
    account_id          VARCHAR(64)   NOT NULL,
    card_id             VARCHAR(64)   NULL,
    device_id           VARCHAR(64)   NULL,
    merchant_id         VARCHAR(64)   NOT NULL,
    txn_dt              DATETIME2(3)  NOT NULL,
    amount              DECIMAL(12,2) NOT NULL,
    currency            CHAR(3)       NOT NULL DEFAULT 'EUR',
    country_iso         CHAR(2)       NOT NULL,
    city                VARCHAR(64)   NULL,
    channel             VARCHAR(16)   NOT NULL,  -- POS/WEB/MOBILE
    entry_mode          VARCHAR(16)   NULL,      -- CHIP/SWIPE/TAP/KEYED
    ip                  VARCHAR(64)   NULL,
    distance_km_prev    DECIMAL(10,2) NULL,
    txn_in_last_min5    INT           NULL,
    is_international    BIT           NOT NULL,
    is_new_device       BIT           NOT NULL,
    is_night            BIT           NOT NULL,
    is_high_amount      BIT           NOT NULL,
    is_fraud            BIT           NOT NULL
);
GO


--Login Events(Authentication Telemetry)
IF OBJECT_ID('stg.login_events','U') IS NOT NULL DROP TABLE stg.login_events;
GO
CREATE TABLE stg.login_events (
    event_id    VARCHAR(64)  NOT NULL PRIMARY KEY,
    customer_id VARCHAR(64)  NOT NULL,
    device_id   VARCHAR(64)  NULL,
    event_dt    DATETIME2(3) NOT NULL,
    ip          VARCHAR(64)  NULL,
    geo         VARCHAR(64)  NULL,
    success     BIT          NOT NULL,
    mfa_used    BIT          NOT NULL
);
GO


--Chargebacks(dekayed fraud labels)
IF OBJECT_ID('stg.chargebacks','U') IS NOT NULL DROP TABLE stg.chargebacks;
GO
CREATE TABLE stg.chargebacks (
    cb_id        VARCHAR(64)  NOT NULL PRIMARY KEY,
    txn_id       VARCHAR(64)  NOT NULL,
    reason_code  VARCHAR(32)  NOT NULL,
    filed_dt     DATETIME2(3) NOT NULL,
    won_dispute  BIT          NOT NULL
);
GO


--Merchants(merchant-level risk)
IF OBJECT_ID('stg.merchants','U') IS NOT NULL DROP TABLE stg.merchants;
GO
CREATE TABLE stg.merchants (
    merchant_id     VARCHAR(64)   NOT NULL PRIMARY KEY,
    category_mcc    VARCHAR(64)   NOT NULL,
    risk_bucket     VARCHAR(16)   NOT NULL,   -- LOW/MED/HIGH
    country_iso     CHAR(2)       NOT NULL,
    avg_ticket      DECIMAL(12,2) NULL,
    velocity_cap    INT           NULL
);
GO


--Devices(device trust profile)
IF OBJECT_ID('stg.devices','U') IS NOT NULL DROP TABLE stg.devices;
GO
CREATE TABLE stg.devices (
    device_id        VARCHAR(64)  NOT NULL PRIMARY KEY,
    device_type      VARCHAR(32)  NOT NULL,   -- Mobile/Web/POS
    os               VARCHAR(32)  NULL,
    first_seen_dt    DATETIME2(3) NULL,
    fingerprint_hash VARCHAR(128) NULL,
    is_rooted        BIT          NULL
);
GO


--IP Reputation(network risk data)
IF OBJECT_ID('stg.ip_reputation','U') IS NOT NULL DROP TABLE stg.ip_reputation;
GO
CREATE TABLE stg.ip_reputation (
    ip                VARCHAR(64)   NOT NULL PRIMARY KEY,
    asn               VARCHAR(32)   NULL,
    proxy_type        VARCHAR(32)   NULL,    -- VPN/Proxy/TOR/Residential
    reputation_score  DECIMAL(5,2)  NULL,    -- 0-100
    updated_dt        DATETIME2(3)  NULL
);
GO


--Optional Reference(Accounts (synthetic identity base))
IF OBJECT_ID('stg.accounts','U') IS NOT NULL DROP TABLE stg.accounts;
GO
CREATE TABLE stg.accounts (
    account_id     VARCHAR(64)  NOT NULL PRIMARY KEY,
    customer_name  NVARCHAR(128) NULL,
    email          NVARCHAR(128) NULL,
    country_iso    CHAR(2)       NULL,
    created_dt     DATETIME2(3)  NULL,
    status         VARCHAR(16)   NULL
);
GO


--Lightweight indexes(performance)
CREATE INDEX IX_stg_transactions_txn_dt        ON stg.transactions (txn_dt);
CREATE INDEX IX_stg_transactions_account_id_dt ON stg.transactions (account_id, txn_dt);
CREATE INDEX IX_stg_transactions_device_id_dt  ON stg.transactions (device_id, txn_dt);
CREATE INDEX IX_stg_login_events_cust_dt       ON stg.login_events (customer_id, event_dt);
CREATE INDEX IX_stg_chargebacks_txn            ON stg.chargebacks (txn_id);
GO


--Validation & Dashboard queries
-- List all staging tables
SELECT s.name AS schema_name, t.name AS table_name
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE s.name = 'stg'
ORDER BY t.name;

-- Quick row counts
SELECT 'transactions' AS tbl, COUNT(*) AS rows FROM stg.transactions
UNION ALL SELECT 'login_events', COUNT(*) FROM stg.login_events
UNION ALL SELECT 'chargebacks',  COUNT(*) FROM stg.chargebacks
UNION ALL SELECT 'merchants',    COUNT(*) FROM stg.merchants
UNION ALL SELECT 'devices',      COUNT(*) FROM stg.devices
UNION ALL SELECT 'ip_reputation',COUNT(*) FROM stg.ip_reputation
UNION ALL SELECT 'accounts',     COUNT(*) FROM stg.accounts;
GO


--Quick check
SELECT 
    s.name AS schema_name, 
    t.name AS table_name, 
    SUM(p.rows) AS row_count
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
LEFT JOIN sys.partitions p ON t.object_id = p.object_id AND p.index_id IN (0,1)
WHERE s.name = 'stg'
GROUP BY s.name, t.name
ORDER BY t.name;
