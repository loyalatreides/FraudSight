--Generic: Row counts & basic null checks
--Row count per GOLD table
SELECT 'account_360'         AS table_name, COUNT(*) AS row_count FROM gold.account_360
UNION ALL
SELECT 'merchant_risk',                    COUNT(*) FROM gold.merchant_risk
UNION ALL
SELECT 'login_risk',                       COUNT(*) FROM gold.login_risk
UNION ALL
SELECT 'transaction_features',            COUNT(*) FROM gold.transaction_features
UNION ALL
SELECT 'fraud_labels',                    COUNT(*) FROM gold.fraud_labels
UNION ALL
SELECT 'daily_account_agg',               COUNT(*) FROM gold.daily_account_agg;

--Template: null profile for key columns
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN account_id IS NULL THEN 1 ELSE 0 END) AS null_account_id,
    SUM(CASE WHEN txn_count  IS NULL THEN 1 ELSE 0 END) AS null_txn_count
FROM gold.account_360;

--GOLD.account_360 — account-level QA & high-risk customers
--Null + sanity check for account_360
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN account_id IS NULL THEN 1 ELSE 0 END)          AS null_account_id,
    SUM(CASE WHEN customer_name IS NULL THEN 1 ELSE 0 END)       AS null_customer_name,
    SUM(CASE WHEN country_iso IS NULL THEN 1 ELSE 0 END)         AS null_country_iso,
    SUM(CASE WHEN txn_count IS NULL THEN 1 ELSE 0 END)           AS null_txn_count,
    SUM(CASE WHEN total_spend IS NULL THEN 1 ELSE 0 END)         AS null_total_spend,
    SUM(CASE WHEN chargeback_count IS NULL THEN 1 ELSE 0 END)    AS null_chargeback_count
FROM gold.account_360;

--Top 20 highest-spend accounts
SELECT TOP 20
    account_id,
    customer_name,
    country_iso,
    txn_count,
    total_spend,
    avg_txn_amount,
    chargeback_count,
    last_chargeback_dt
FROM gold.account_360
ORDER BY total_spend DESC;

--High-risk customers (simple rule-based: many frauds/chargebacks)
SELECT TOP 50
    account_id,
    customer_name,
    country_iso,
    txn_count,
    total_spend,
    intl_txn_count,
    night_txn_count,
    chargeback_count,
    won_dispute_count
FROM gold.account_360
WHERE
    (chargeback_count >= 3)
    OR (intl_txn_count >= 10)
    OR (night_txn_count >= 15)
ORDER BY chargeback_count DESC, intl_txn_count DESC;

--GOLD.merchant_risk — merchant QA, fraud & chargeback rates
--Null + sanity check for merchant_risk
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN merchant_id IS NULL THEN 1 ELSE 0 END)      AS null_merchant_id,
    SUM(CASE WHEN category_mcc IS NULL THEN 1 ELSE 0 END)     AS null_category_mcc,
    SUM(CASE WHEN risk_bucket IS NULL THEN 1 ELSE 0 END)      AS null_risk_bucket,
    SUM(CASE WHEN txn_count IS NULL THEN 1 ELSE 0 END)        AS null_txn_count,
    SUM(CASE WHEN cb_count IS NULL THEN 1 ELSE 0 END)         AS null_cb_count,
    SUM(CASE WHEN chargeback_rate IS NULL THEN 1 ELSE 0 END)  AS null_chargeback_rate
FROM gold.merchant_risk;

--Top merchants by total volume
SELECT TOP 20
    merchant_id,
    category_mcc,
    risk_bucket,
    country_iso,
    txn_count,
    total_volume,
    avg_txn_amount,
    flagged_fraud_count,
    cb_count,
    chargeback_rate
FROM gold.merchant_risk
ORDER BY total_volume DESC;

--Top merchants by chargeback rate (min volume filter)
SELECT TOP 20
    merchant_id,
    category_mcc,
    risk_bucket,
    country_iso,
    txn_count,
    cb_count,
    chargeback_rate
FROM gold.merchant_risk
WHERE txn_count >= 100        -- avoid noisy very-low-volume merchants
ORDER BY chargeback_rate DESC, cb_count DESC;

--Outlier merchants (high fraud + high chargebacks)
SELECT TOP 20
    merchant_id,
    category_mcc,
    risk_bucket,
    txn_count,
    flagged_fraud_count,
    cb_count,
    chargeback_rate
FROM gold.merchant_risk
WHERE
    flagged_fraud_count >= 50
    OR cb_count >= 30
ORDER BY flagged_fraud_count DESC, cb_count DESC;

--GOLD.login_risk — login QA & risky customers
--Null check for login_risk
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN customer_id IS NULL THEN 1 ELSE 0 END)          AS null_customer_id,
    SUM(CASE WHEN login_count IS NULL THEN 1 ELSE 0 END)          AS null_login_count,
    SUM(CASE WHEN avg_ip_reputation IS NULL THEN 1 ELSE 0 END)    AS null_avg_ip_rep,
    SUM(CASE WHEN unique_devices IS NULL THEN 1 ELSE 0 END)       AS null_unique_devices,
    SUM(CASE WHEN rooted_device_logins IS NULL THEN 1 ELSE 0 END) AS null_rooted_logins
FROM gold.login_risk;

--Top risky customers by failed logins & low IP reputation
SELECT TOP 50
    lr.customer_id,
    lr.login_count,
    lr.failed_logins,
    lr.failed_no_mfa,
    lr.avg_ip_reputation,
    lr.unique_ips,
    lr.unique_devices,
    lr.rooted_device_logins,
    a.country_iso,
    a.status
FROM gold.login_risk lr
LEFT JOIN gold.account_360 a
    ON lr.customer_id = a.account_id
WHERE
    lr.login_count >= 10
    AND lr.failed_logins >= 3
    AND lr.avg_ip_reputation < 40     -- low reputation
ORDER BY lr.failed_logins DESC, lr.avg_ip_reputation ASC;

--Customers logging in from many devices / IPs
SELECT TOP 50
    lr.customer_id,
    lr.login_count,
    lr.unique_ips,
    lr.unique_devices,
    lr.rooted_device_logins
FROM gold.login_risk lr
WHERE
    lr.unique_devices >= 5
    OR lr.unique_ips >= 10
ORDER BY lr.unique_devices DESC, lr.unique_ips DESC;

--GOLD.fraud_labels — fraud rate & patterns
--Overall fraud and chargeback rate
SELECT
    COUNT(*) AS total_txns,
    SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END)            AS fraud_txns,
    100.0 * SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END)
        / COUNT(*)                                           AS fraud_rate_pct,
    SUM(CASE WHEN is_chargeback = 1 THEN 1 ELSE 0 END)       AS cb_txns,
    100.0 * SUM(CASE WHEN is_chargeback = 1 THEN 1 ELSE 0 END)
        / COUNT(*)                                           AS cb_rate_pct
FROM gold.fraud_labels;

--Fraud/chargeback rate by day
SELECT
    CAST(txn_dt AS DATE) AS txn_date,
    COUNT(*) AS total_txns,
    SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END)      AS fraud_txns,
    100.0 * SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END) / COUNT(*) AS fraud_rate_pct,
    SUM(CASE WHEN is_chargeback = 1 THEN 1 ELSE 0 END) AS cb_txns,
    100.0 * SUM(CASE WHEN is_chargeback = 1 THEN 1 ELSE 0 END) / COUNT(*) AS cb_rate_pct
FROM gold.fraud_labels
GROUP BY CAST(txn_dt AS DATE)
ORDER BY txn_date;

--Fraud by country
SELECT TOP 20
    country_iso,
    COUNT(*) AS total_txns,
    SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END) AS fraud_txns,
    100.0 * SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END) / COUNT(*) AS fraud_rate_pct
FROM gold.fraud_labels
GROUP BY country_iso
ORDER BY fraud_rate_pct DESC, fraud_txns DESC;

--High-value fraud outliers
SELECT TOP 50
    txn_id,
    account_id,
    merchant_id,
    txn_dt,
    amount,
    country_iso,
    is_fraud,
    is_chargeback
FROM gold.fraud_labels
WHERE
    is_fraud = 1
    AND amount >= 500       -- you can tune this threshold
ORDER BY amount DESC;

--GOLD.transaction_features — behavioral outliers
--Check nulls on engineered columns
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN prev_txn_ts IS NULL THEN 1 ELSE 0 END)         AS null_prev_txn_ts,
    SUM(CASE WHEN prev_amount IS NULL THEN 1 ELSE 0 END)         AS null_prev_amount,
    SUM(CASE WHEN amount_change IS NULL THEN 1 ELSE 0 END)       AS null_amount_change,
    SUM(CASE WHEN mins_since_prev_txn IS NULL THEN 1 ELSE 0 END) AS null_mins_since_prev
FROM gold.transaction_features;

--Very rapid transactions (possible bot/card testing)
SELECT TOP 50
    account_id,
    txn_id,
    txn_dt,
    amount,
    prev_txn_ts,
    mins_since_prev_txn,
    country_iso,
    is_fraud
FROM gold.transaction_features
WHERE
    mins_since_prev_txn IS NOT NULL
    AND mins_since_prev_txn <= 1    -- less than 1 minute
ORDER BY mins_since_prev_txn ASC;

--Wild amount jumps (amount_change outliers)
SELECT TOP 50
    account_id,
    txn_id,
    txn_dt,
    prev_txn_ts,
    prev_amount,
    amount,
    amount_change,
    is_fraud
FROM gold.transaction_features
WHERE
    prev_amount IS NOT NULL
    AND ABS(amount_change) >= 400    -- large sudden jump
ORDER BY ABS(amount_change) DESC;

--GOLD.daily_account_agg — daily risk pattern checks
--Basic QA for daily_account_agg
SELECT
    COUNT(*) AS total_rows,
    SUM(CASE WHEN account_id IS NULL THEN 1 ELSE 0 END)          AS null_account_id,
    SUM(CASE WHEN txn_date IS NULL THEN 1 ELSE 0 END)            AS null_txn_date,
    SUM(CASE WHEN daily_spend IS NULL THEN 1 ELSE 0 END)         AS null_daily_spend,
    SUM(CASE WHEN daily_txn_count IS NULL THEN 1 ELSE 0 END)     AS null_daily_txn_count,
    SUM(CASE WHEN daily_fraud_flags IS NULL THEN 1 ELSE 0 END)   AS null_daily_fraud_flags
FROM gold.daily_account_agg;

--Days with unusually high spend per account
SELECT TOP 50
    account_id,
    txn_date,
    daily_spend,
    daily_txn_count,
    daily_fraud_flags
FROM gold.daily_account_agg
WHERE
    daily_spend >= 2000    -- adjust threshold as needed
ORDER BY daily_spend DESC;

--Accounts with repeated fraud days
SELECT
    account_id,
    COUNT(*) AS fraud_days,
    SUM(daily_fraud_flags) AS total_fraud_txns
FROM gold.daily_account_agg
WHERE daily_fraud_flags > 0
GROUP BY account_id
HAVING COUNT(*) >= 3
ORDER BY fraud_days DESC, total_fraud_txns DESC;
