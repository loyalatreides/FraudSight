/* ==========================================================
   FRAUD ANALYTICS PROJECT – STAGING TABLE CREATION SCRIPT
   ----------------------------------------------------------
   Database: sqldb-fr-risk
   Schema  : stg
   Purpose : Raw (string-type) ingestion tables for ADF Copy
   Author  : Kamran Habib
   Date    : 2025-11-10
   ========================================================== */

-- Create schema if not exists
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'stg')
    EXEC('CREATE SCHEMA stg');
GO

/* =======================
   1. TRANSACTIONS
   ======================= */
IF OBJECT_ID('stg.transactions') IS NULL
BEGIN
    CREATE TABLE stg.transactions (
        txn_id            VARCHAR(64) NULL,
        account_id        VARCHAR(64) NULL,
        card_id           VARCHAR(64) NULL,
        device_id         VARCHAR(64) NULL,
        merchant_id       VARCHAR(64) NULL,
        txn_dt            VARCHAR(64) NULL,
        amount            VARCHAR(64) NULL,
        currency          VARCHAR(16) NULL,
        country_iso       VARCHAR(8)  NULL,
        city              VARCHAR(128) NULL,
        channel           VARCHAR(32) NULL,
        entry_mode        VARCHAR(32) NULL,
        ip                VARCHAR(64) NULL,
        distance_km_prev  VARCHAR(64) NULL,
        txn_in_last_min5  VARCHAR(64) NULL,
        is_international  VARCHAR(16) NULL,
        is_new_device     VARCHAR(16) NULL,
        is_night          VARCHAR(16) NULL,
        is_high_amount    VARCHAR(16) NULL,
        is_fraud          VARCHAR(16) NULL
    );
END
GO

/* =======================
   2. ACCOUNTS
   ======================= */
IF OBJECT_ID('stg.accounts') IS NULL
BEGIN
    CREATE TABLE stg.accounts (
        account_id    VARCHAR(64)  NULL,
        customer_name VARCHAR(128) NULL,
        email         VARCHAR(128) NULL,
        country_iso   VARCHAR(8)   NULL,
        created_dt    VARCHAR(64)  NULL,
        status        VARCHAR(32)  NULL
    );
END
GO

/* =======================
   3. MERCHANTS
   ======================= */
IF OBJECT_ID('stg.merchants') IS NULL
BEGIN
    CREATE TABLE stg.merchants (
        merchant_id   VARCHAR(64)  NULL,
        category_mcc  VARCHAR(8)   NULL,
        risk_bucket   VARCHAR(8)   NULL,
        country_iso   VARCHAR(8)   NULL,
        avg_ticket    VARCHAR(32)  NULL,
        velocity_cap  VARCHAR(32)  NULL
    );
END
GO

/* =======================
   4. DEVICES
   ======================= */
IF OBJECT_ID('stg.devices') IS NULL
BEGIN
    CREATE TABLE stg.devices (
        device_id        VARCHAR(64) NULL,
        device_type      VARCHAR(64) NULL,
        os               VARCHAR(64) NULL,
        first_seen_dt    VARCHAR(64) NULL,
        fingerprint_hash VARCHAR(64) NULL,
        is_rooted        VARCHAR(16) NULL
    );
END
GO

/* =======================
   5. CHARGEBACKS
   ======================= */
IF OBJECT_ID('stg.chargebacks') IS NULL
BEGIN
    CREATE TABLE stg.chargebacks (
        cb_id        VARCHAR(64)  NULL,
        txn_id       VARCHAR(64)  NULL,
        reason_code  VARCHAR(64)  NULL,
        filed_dt     VARCHAR(64)  NULL,
        won_dispute  VARCHAR(16)  NULL
    );
END
GO

/* =======================
   6. LOGIN EVENTS
   ======================= */
IF OBJECT_ID('stg.login_events') IS NULL
BEGIN
    CREATE TABLE stg.login_events (
        event_id     VARCHAR(64)  NULL,
        customer_id  VARCHAR(64)  NULL,
        device_id    VARCHAR(64)  NULL,
        event_dt     VARCHAR(64)  NULL,
        ip           VARCHAR(64)  NULL,
        geo          VARCHAR(64)  NULL,
        success      VARCHAR(16)  NULL,
        mfa_used     VARCHAR(16)  NULL
    );
END
GO

/* =======================
   7. IP REPUTATION
   ======================= */
IF OBJECT_ID('stg.ip_reputation') IS NULL
BEGIN
    CREATE TABLE stg.ip_reputation (
        ip               VARCHAR(64) NULL,
        asn              VARCHAR(32) NULL,
        proxy_type       VARCHAR(32) NULL,
        reputation_score VARCHAR(32) NULL,
        updated_dt       VARCHAR(64) NULL
    );
END
GO

/* =======================
   8. BLACKLIST (Optional)
   ======================= */
IF OBJECT_ID('stg.blacklist') IS NULL
BEGIN
    CREATE TABLE stg.blacklist (
        ip             VARCHAR(64)  NULL,
        device_id      VARCHAR(64)  NULL,
        account_id     VARCHAR(64)  NULL,
        merchant_id    VARCHAR(64)  NULL,
        reason         VARCHAR(128) NULL,
        added_dt       VARCHAR(64)  NULL
    );
END
GO

/* =======================
   Summary
   ======================= */
PRINT '✅ All STG tables verified/created successfully under schema [stg].';
GO
